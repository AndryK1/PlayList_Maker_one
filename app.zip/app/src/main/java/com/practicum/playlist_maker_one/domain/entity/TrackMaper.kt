package com.practicum.playlist_maker_one.domain.entity

import com.practicum.playlist_maker_one.data.dto.TrackDataDto

interface TrackMapper{
    fun map(trackDataDto: TrackDataDto) : TrackData
}
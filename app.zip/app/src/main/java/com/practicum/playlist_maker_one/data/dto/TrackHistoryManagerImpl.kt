package com.practicum.playlist_maker_one.data.dto

import android.content.Context
import android.content.Context.MODE_PRIVATE
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.practicum.playlist_maker_one.ui.track.APP_PREFERENCES
import com.practicum.playlist_maker_one.ui.track.HISTORY_KEY
import com.practicum.playlist_maker_one.domain.api.TrackHistoryManager
import com.practicum.playlist_maker_one.domain.entity.TrackData


object TrackHistoryManagerImpl : TrackHistoryManager{

    private var trackHistory = mutableListOf<TrackData>()
    private lateinit var lastTrack : TrackData

    override fun initializeHistory(context: Context) {
        trackHistory = getHistory(context)
    }

    override fun addTrackToHistory(track: TrackData) {

        if ((trackHistory.size < 10) && !trackHistory.contains(track)) {
            trackHistory.add(0,track)
        }
        else if ((trackHistory.size >= 10) && !trackHistory.contains(track)) {
            trackHistory.removeAt(0)
            trackHistory.add(0,track)
        }
        else if (trackHistory.contains(track)) {
            trackHistory.remove(track)
            trackHistory.add(0, track)
        }
    }

    override fun saveHistory( context : Context){
        val sharedPrefs = context.getSharedPreferences(APP_PREFERENCES, MODE_PRIVATE)
        val json = Gson().toJson(trackHistory)
        sharedPrefs.edit()
            .putString(HISTORY_KEY, json)
            .apply()

    }

    override fun getHistory(context : Context) : MutableList<TrackData>{
        val sharedPrefs = context.getSharedPreferences(APP_PREFERENCES, MODE_PRIVATE)
        val json = sharedPrefs.getString(HISTORY_KEY, null)
        var list: MutableList<TrackData> = mutableListOf()
        if(json != null)
        {
            val type = object : TypeToken<MutableList<TrackData>>() {}.type
            list = Gson().fromJson(json, type)
            return list
        }
        else{
            return list
        }
    }

    override fun deliteHistory(context: Context){
        trackHistory.clear()
        saveHistory(context)
    }

    override fun getTrackHistory(): List<TrackData> {
        return trackHistory
    }

    override fun putLastTrack(track: TrackData){
        lastTrack = track
    }

    override fun getLastTrack(): TrackData {
        return lastTrack
    }

    override fun getCoverArtwork(track: TrackData) = track.artworkUrl100.replaceAfterLast('/',"512x512bb.jpg")
}
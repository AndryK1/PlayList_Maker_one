package com.practicum.playlist_maker_one.data.network

interface NetworkClient {
    fun doSearch(dto: Any) : Response
}
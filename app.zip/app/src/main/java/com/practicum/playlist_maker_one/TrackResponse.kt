package com.practicum.playlist_maker_one

import com.practicum.playlist_maker_one.domain.entity.TrackData

class TrackResponse(
    val results : List<TrackData>
)
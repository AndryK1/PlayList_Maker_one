package com.practicum.playlist_maker_one.data.network

class TrackSearchRequest (val request: String){
}
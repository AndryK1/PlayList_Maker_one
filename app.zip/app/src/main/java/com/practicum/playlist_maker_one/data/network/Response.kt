package com.practicum.playlist_maker_one.data.network

open class Response() {
    var resultCode = 0 //меняя эту переменную сообщяем коду верно ли совершился запрос
}
package com.practicum.playlist_maker_one.data.network

import com.practicum.playlist_maker_one.data.dto.TrackDataDto

class TrackSearchResponse(val searchType: String,
                          val expression: String,
                          val results: List<TrackDataDto>) : Response()
